﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WarButton : MonoBehaviour
{
    public GameObject leader;

    public void WarButtonClick()
    {
        //更新LeaderOrderManager中的order状态
        leader.GetComponent<LeaderOrderManager>().isWar = true;
        leader.GetComponent<LeaderOrderManager>().isRetire = false;
        leader.GetComponent<LeaderOrderManager>().isProduct = false;


        if (leader.GetComponent<LeaderOrderManager>().isWar)
        {
            //找到所有villager
            GameObject[] allVillagers = GameObject.FindGameObjectsWithTag("Villager");
            GameObject[] allArchers = GameObject.FindGameObjectsWithTag("Archer");
            GameObject[] allAxeSolider = GameObject.FindGameObjectsWithTag("AxeSolider");
            GameObject[] allLabor = GameObject.FindGameObjectsWithTag("Labor");
            GameObject[] allGatherers = GameObject.FindGameObjectsWithTag("Gatherers");
            //合并到新数组
            GameObject[] all = new GameObject[allVillagers.Length + allArchers.Length + allAxeSolider.Length + allLabor.Length + allGatherers.Length];
            allVillagers.CopyTo(all, 0);
            allArchers.CopyTo(all, allVillagers.Length);
            allAxeSolider.CopyTo(all, allVillagers.Length + allArchers.Length);
            allLabor.CopyTo(all, allVillagers.Length + allArchers.Length + allAxeSolider.Length);
            allGatherers.CopyTo(all, allVillagers.Length + allArchers.Length + allAxeSolider.Length + allLabor.Length);

            int length = all.Length;
            for (int i = 0; i < length; i++)
            {
                if (all[i].GetComponent<FollowLeader>().isInArmy)
                {
                    //取消撤退
                    all[i].GetComponent<FollowLeader>().isRetire = false;
                    //跟随首领速度为4
                    all[i].GetComponent<FollowLeader>().speed = 4;
                    //冲向敌人速度为5
                    if (all[i].GetComponent<FindEnemy>() != null)
                        all[i].GetComponent<FindEnemy>().villageSpeed = 5;
                    //禁用普通状态视野范围
                    GameObject normalVillagerFindRange = all[i].transform.Find("VillagerNormalFindRange").gameObject;
                    normalVillagerFindRange.SetActive(false);
                    //启用战争状态视野范围
                    GameObject warVillagerFindRange = all[i].transform.Find("VillagerWarFindRange").gameObject;
                    warVillagerFindRange.SetActive(true);
                }

            }
        }

    }
}
