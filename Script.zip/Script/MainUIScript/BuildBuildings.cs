﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class BuildBuildings : MonoBehaviour
{
    public bool isBuilding=false;
    // 建筑物预制体
    public GameObject smallHouse,mediumHouse,bigHouse,smallStore,bigStore;
    // 要建造的建筑
    GameObject buildingToBuild;

    ResourcesManager resourcesManager;
    // hitPoint鼠标点击地面的位置,offset建筑生成时向上的偏移量
    Vector3 hitPoint, offset;
    Vector3 newHitPoint;

    private void Start()
    {
        hitPoint = Vector3.zero;
        newHitPoint = hitPoint;
        // 资源管理类在地面上
        resourcesManager = GameObject.FindGameObjectWithTag("Ground").GetComponent<ResourcesManager>();
    }

    void Update()
    {
        // 如果鼠标不在UI上
        if (!EventSystem.current.IsPointerOverGameObject())
        {
            // 处于建造状态
            if (isBuilding)
            {
                TryToBuild();
            }
        }
    }

    void TryToBuild()
    {
        // 新的点击位置
        newHitPoint = PublicFunction.GetMouseHitPoint(hitPoint, "Ground");
        if (hitPoint != newHitPoint)
        {
            if (CostMoney(buildingToBuild))
            {
                Instantiate(buildingToBuild, newHitPoint + offset, buildingToBuild.transform.rotation);
            }
            else
            {
                Debug.Log("资源不足");
            }
        }
        hitPoint = newHitPoint;
    }

    bool CostMoney(GameObject theBuild)
    {
        int buildingWoodCost = theBuild.GetComponent<BuildingCost>().buildingWoodCost;
        int leftWood = resourcesManager.woodInVillage - buildingWoodCost;
        if (leftWood >= 0)
        {
            resourcesManager.woodInVillage = leftWood;
            return true;
        }
        return false;

    }

    // 小房子建造按钮
    public void SmallHouseBuild()
    {
        // 建筑高度的一半
        float tall = 2.5f;
        // 建筑生成时在半空的位置
        // （注：在尝试用其它方法判断建筑建造合法性失败后，这里采用建筑下落到地面之前碰到其它物体即失败的暂时办法）
        float fly = 10f;
        Vector3 _offset = new Vector3(0, tall+fly, 0);
        offset = _offset;
        isBuilding = true;
        buildingToBuild = smallHouse;
    }

    // 中房子建造按钮
    public void MediumHouseBuild()
    {
        // 建筑生成时在半空的位置
        float fly = 13f;
        Vector3 _offset = new Vector3(0, fly, 0);
        offset = _offset;
        isBuilding = true;
        buildingToBuild = mediumHouse;
    }

    // 大房子建造按钮
    public void BigHouseBuild()
    {
        // 建筑生成时在半空的位置
        float fly = 13f;
        Vector3 _offset = new Vector3(0, fly, 0);
        offset = _offset;
        isBuilding = true;
        buildingToBuild = bigHouse;
    }

    // 小仓库建造按钮
    public void SmallStoreBuild()
    {
        // 建筑生成时在半空的位置
        float fly = 13f;
        Vector3 _offset = new Vector3(0, fly, 0);
        offset = _offset;
        isBuilding = true;
        buildingToBuild = smallStore;
    }

    // 大仓库建造按钮
    public void BigStoreBuild()
    {
        // 建筑生成时在半空的位置
        float fly = 13f;
        Vector3 _offset = new Vector3(0, fly, 0);
        offset = _offset;
        isBuilding = true;
        buildingToBuild = bigStore;
    }
}
