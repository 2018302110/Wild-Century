﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BuildButton : MonoBehaviour
{
    public GameObject buildListPanel;
    public Text text;

    
    public void BuildButtonDown()
    {
        if (buildListPanel.activeSelf)
        {
            buildListPanel.SetActive(false);
            text.text = "建造";
            // 未处于建造状态
            GetComponent<BuildBuildings>().isBuilding = false;
        }
        else
        {
            buildListPanel.SetActive(true);
            text.text = "返回";
        }
    }
}
