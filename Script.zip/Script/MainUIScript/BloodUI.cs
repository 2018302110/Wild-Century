﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BloodUI : MonoBehaviour
{
    //当前摄像机对象
    private Camera cameraCurrent;
    //生物名称
    public string biologyName;
    //生物模型高度
    float biologyHeight;
    //红色血条贴图
    public Texture2D blood_red;
    //黑色血条贴图
    public Texture2D blood_black;
    //生物最大血值
    public int maxHP;
    public int hp;

    void Start()
    {
        maxHP = GetComponent<AttributeManager>().HP;
        hp = maxHP;
        //得到摄像机对象
        cameraCurrent = Camera.main;

        //得到模型原始高度
        float size_y = transform.GetComponent<Collider>().bounds.size.y;
        //得到模型缩放比例
        float scal_y = transform.localScale.y;
        //它们的乘积就是高度
        biologyHeight = (size_y * scal_y);

    }

    void Update()
    {

    }

    void OnGUI()
    {
        float offset = 1;
        //得到NPC头顶在3D世界中的坐标
        Vector3 worldPosition = new Vector3(transform.position.x, transform.position.y + biologyHeight + offset, transform.position.z);
        //根据NPC头顶的3D坐标换算成它在2D屏幕中的坐标
        Vector2 position = cameraCurrent.WorldToScreenPoint(worldPosition);
        //得到真实NPC头顶的2D坐标
        position = new Vector2(position.x, Screen.height - position.y);

        //血条图片缩放的倍数
        float scaleImage = 0.2f;
        //计算出血条的宽高
        Vector2 bloodSize = (GUI.skin.label.CalcSize(new GUIContent(blood_red))) * scaleImage;
        //通过血值计算红色血条显示区域
        hp = GetComponent<AttributeManager>().HP;
        if (hp <= 0)
        {

            GameObject.FindGameObjectWithTag("Ground").GetComponent<ResourcesManager>().isChangeWorkChanged = true;
            Destroy(gameObject);
        }
        float blood_width = blood_red.width * hp / maxHP * scaleImage;
        //先绘制黑色血条
        GUI.DrawTexture(new Rect(position.x - (bloodSize.x / 2), position.y - bloodSize.y, bloodSize.x, bloodSize.y), blood_black);
        //在绘制红色血条
        GUI.DrawTexture(new Rect(position.x - (bloodSize.x / 2), position.y - bloodSize.y, blood_width, bloodSize.y), blood_red);

        //计算NPC名称的宽高
        Vector2 nameSize = GUI.skin.label.CalcSize(new GUIContent(biologyName));
        //设置显示颜色为黄色
        GUI.color = Color.yellow;
        //绘制NPC名称
        GUI.Label(new Rect(position.x - (nameSize.x / 2), position.y - nameSize.y - bloodSize.y, nameSize.x, nameSize.y), biologyName);

    }

}
