﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MenuButton : MonoBehaviour
{

    public GameObject menuPanel;
    [SerializeField] Text text;

    public void OnMenuButton()
    {
        if (!menuPanel.activeSelf)
        {
            menuPanel.SetActive(true);
            text.text = "返回";
        }
        else
        {
            menuPanel.SetActive(false);
            text.text = "菜单";
        }
    }

}
