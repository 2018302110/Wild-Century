﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using UnityEngine.SceneManagement;

public class SaveButton : MonoBehaviour
{
    // 物资
    public int foodInArmy;
    public int waterInArmy;
    public int woodInArmy;
    public int weaponInArmy;
    public int foodInVillage;
    public int waterInVillage;
    public int woodInVillage;
    public int weaponInVillage;
    // 仓库容量
    public int maxWeightStore;

    public void SaveGame()
    {
        SaveFile saveFile = CreateSaveFile();
        // 创建了一个 BinaryFormatter，然后创建一个 FileStream，在创建时指定文件路径和要保存的 saveFile 对象。
        // 它会序列化数据（转换成字节），然后写磁盘，关闭 FileStream。现在在电脑上会多一个名为 gamesave.savefile 的文件。
        BinaryFormatter bf = new BinaryFormatter();
        FileStream file = File.Create(Application.persistentDataPath + "/gamesave.savefile");
        bf.Serialize(file, saveFile);
        file.Close();
        Debug.Log("Game Saved");

    }

    public SaveFile CreateSaveFile()
    {
        // 所有人
        GameObject[] allVillager = GameObject.FindGameObjectsWithTag("Villager");
        GameObject[] allAxeSolider = GameObject.FindGameObjectsWithTag("AxeSolider");
        GameObject[] allArcher = GameObject.FindGameObjectsWithTag("Archer");
        GameObject[] allLabor = GameObject.FindGameObjectsWithTag("Labor");
        GameObject[] allGatherers = GameObject.FindGameObjectsWithTag("Gatherers");
        // 所有建筑
        GameObject[] allSmallHouse = GameObject.FindGameObjectsWithTag("SmallHouse");
        GameObject[] allMediumHouse = GameObject.FindGameObjectsWithTag("MediumHouse");
        GameObject[] allBigHouse = GameObject.FindGameObjectsWithTag("BigHouse");
        GameObject[] allSmallStore = GameObject.FindGameObjectsWithTag("SmallStore");
        GameObject[] allBigStore = GameObject.FindGameObjectsWithTag("BigStore");

        // 存档文件类实例
        SaveFile saveFile = new SaveFile();
        int i = 0;

        #region 保存物体
        void SaveObject(SaveFile _saveFile,GameObject[] obj)
        {
            foreach (GameObject targetGameObject in obj)
            {
                // 存位置和旋转
                saveFile.targetPositionsX.Add(targetGameObject.transform.position.x);
                saveFile.targetPositionsY.Add(targetGameObject.transform.position.y);
                saveFile.targetPositionsZ.Add(targetGameObject.transform.position.z);
                saveFile.targetRotationX.Add(targetGameObject.transform.rotation.eulerAngles.x);
                saveFile.targetRotationY.Add(targetGameObject.transform.rotation.eulerAngles.y);
                saveFile.targetRotationZ.Add(targetGameObject.transform.rotation.eulerAngles.z);

                // 存tag
                saveFile.targetsTypes.Add(targetGameObject.tag);
                i++;
            }
        }

        SaveObject(saveFile, allVillager);
        SaveObject(saveFile, allAxeSolider);
        SaveObject(saveFile, allArcher);
        SaveObject(saveFile, allLabor);
        SaveObject(saveFile, allGatherers);
        SaveObject(saveFile, allSmallHouse);
        SaveObject(saveFile, allMediumHouse);
        SaveObject(saveFile, allBigHouse);
        SaveObject(saveFile, allSmallStore);
        SaveObject(saveFile, allBigStore);
        #endregion

        #region 保存资源
        ResourcesManager resource = GameObject.FindGameObjectWithTag("Ground").GetComponent<ResourcesManager>();

        saveFile.foodInArmy = resource.foodInArmy;
        saveFile.waterInArmy = resource.waterInArmy;
        saveFile.woodInArmy = resource.woodInArmy;
        saveFile.weaponInArmy = resource.weaponInArmy;
        saveFile.foodInVillage = resource.foodInVillage;
        saveFile.waterInVillage = resource.waterInVillage;
        saveFile.woodInVillage = resource.woodInVillage;
        saveFile.weaponInVillage = resource.weaponInVillage;
        saveFile.maxWeightStore = resource.maxWeightStore;
        #endregion

        return saveFile;
    }
}
