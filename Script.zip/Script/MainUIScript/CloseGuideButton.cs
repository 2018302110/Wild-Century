﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CloseGuideButton : MonoBehaviour
{
    [SerializeField] GameObject guidPanel;

    public void OnCloseGuideButton()
    {
        guidPanel.SetActive(false);
    }
}
