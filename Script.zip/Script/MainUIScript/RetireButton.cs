﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RetireButton : MonoBehaviour
{
    public GameObject leader;

    public void RetireButtonClick()
    {
        //更新LeaderOrderManager中的order状态
        leader.GetComponent<LeaderOrderManager>().isWar = false;
        leader.GetComponent<LeaderOrderManager>().isRetire = true;
        leader.GetComponent<LeaderOrderManager>().isProduct = false;


        if (leader.GetComponent<LeaderOrderManager>().isRetire)
        {
            //找到所有villager
            GameObject[] allVillagers = GameObject.FindGameObjectsWithTag("Villager");
            GameObject[] allArchers = GameObject.FindGameObjectsWithTag("Archer");
            GameObject[] allAxeSolider = GameObject.FindGameObjectsWithTag("AxeSolider");
            GameObject[] allLabor = GameObject.FindGameObjectsWithTag("Labor");
            GameObject[] allGatherers = GameObject.FindGameObjectsWithTag("Gatherers");
            //合并到新数组
            GameObject[] all = new GameObject[allVillagers.Length + allArchers.Length + allAxeSolider.Length + allLabor.Length + allGatherers.Length];
            allVillagers.CopyTo(all, 0);
            allArchers.CopyTo(all, allVillagers.Length);
            allAxeSolider.CopyTo(all, allVillagers.Length + allArchers.Length);
            allLabor.CopyTo(all, allVillagers.Length + allArchers.Length + allAxeSolider.Length);
            allGatherers.CopyTo(all, allVillagers.Length + allArchers.Length + allAxeSolider.Length + allLabor.Length);

            int length = all.Length;
            for (int i = 0; i < length; i++)
            {
                if (all[i].GetComponent<FollowLeader>().isInArmy)
                {
                    //撤退
                    all[i].GetComponent<FollowLeader>().isRetire = true;
                    //跟随首领速度为6
                    all[i].GetComponent<FollowLeader>().speed = 6;
                    //冲向敌人速度为4
                    if (all[i].GetComponent<FindEnemy>() != null)
                        all[i].GetComponent<FindEnemy>().villageSpeed = 4;
                    //禁用战争状态视野范围
                    GameObject warVillagerFindRange = all[i].transform.Find("VillagerWarFindRange").gameObject;
                    warVillagerFindRange.SetActive(false);
                    //启用普通状态视野范围
                    GameObject normalVillagerFindRange = all[i].transform.Find("VillagerNormalFindRange").gameObject;
                    normalVillagerFindRange.SetActive(true);
                }

            }
        }
    }
}
