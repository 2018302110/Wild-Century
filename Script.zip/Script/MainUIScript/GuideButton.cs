﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GuideButton : MonoBehaviour
{
    [SerializeField] GameObject guidePanel;


    public void onClickGuidButton()
    {
        if (!guidePanel.activeSelf)
        {
            guidePanel.SetActive(true);

        }
        else
        {
            guidePanel.SetActive(false);

        }

    }
}
