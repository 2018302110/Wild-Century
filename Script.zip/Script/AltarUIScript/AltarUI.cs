﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class AltarUI : MonoBehaviour
{
    public bool isLeaderAround = false;
    public GameObject altarPanel, changeWorkPanel, troopsPanel;
    public GameObject axeSoldier, archer, labor, gatherers;
    ResourcesManager resourcesManager;

    void Start()
    {
        altarPanel.SetActive(false);
        resourcesManager = GameObject.FindGameObjectWithTag("Ground").GetComponent<ResourcesManager>();
    }

    void Update()
    {
        //如果鼠标不在UI上
        if (!EventSystem.current.IsPointerOverGameObject())
        {
            //Leader在附近时点击祭坛则打开祭坛面板开启灯光
            if (isLeaderAround && PublicFunction.IsGetMouseHit("Altar"))
            {
                altarPanel.SetActive(true);
                resourcesManager.isVillageChanged = true;
                GetComponent<Light>().enabled = true;
            }
        }
    }

    #region 关闭与打开面板
    //关闭祭坛面板
    public void CloseAltarPanel()
    {
        altarPanel.SetActive(false);
        GetComponent<Light>().enabled = false;
    }

    //打开转职面板
    public void OpenChangeWorkPanel()
    {
        changeWorkPanel.SetActive(true);
        resourcesManager.isChangeWorkChanged = true;
    }

    //关闭转职面板
    public void CloseChangeWorkPanel()
    {
        changeWorkPanel.SetActive(false);
    }

    //打开队伍面板（新的征程）
    public void OpenTroopsPanel()
    {
        troopsPanel.SetActive(true);
        resourcesManager.isChangeTroops = true;
    }

    public void CloseTroopsPanel()
    {
        troopsPanel.SetActive(false);
    }
    #endregion


    #region 训练按钮
    //训练斧兵
    public void TrainAxeSoldierButton()
    {
        int waterCost = 30, foodCost = 15, weaponCost = 2;
        bool canTrain = true;
        //判断资源是否够
        if (resourcesManager.waterInVillage - waterCost < 0)
        {
            canTrain = false;
            Debug.Log("水不够");

        }
        if (resourcesManager.foodInVillage - foodCost < 0)
        {
            canTrain = false;
            Debug.Log("食物不够");
        }
        if (resourcesManager.weaponInVillage - weaponCost < 0)
        {
            canTrain = false;
            Debug.Log("武器不够");
        }

        if (canTrain)
        {
            //找一个村民
            GameObject aVillager = GameObject.FindGameObjectWithTag("Villager");
            //如果找到
            if (aVillager != null)
            {
                //消耗资源并通知刷新
                resourcesManager.waterInVillage -= waterCost;
                resourcesManager.foodInVillage -= foodCost;
                resourcesManager.weaponInVillage -= weaponCost;
                resourcesManager.isVillageChanged = true;

                Vector3 villagerPosition = aVillager.transform.position;
                Destroy(aVillager);
                Instantiate(axeSoldier, villagerPosition, axeSoldier.transform.rotation);
                resourcesManager.isChangeWorkChanged = true;
            }
            else
                Debug.Log("无业者不够");
        }

    }

    //训练弓箭手
    public void TrainArcherButton()
    {
        int waterCost = 40, foodCost = 60, weaponCost = 4;
        bool canTrain = true;
        //判断资源是否够
        if (resourcesManager.waterInVillage - waterCost < 0)
        {
            canTrain = false;
            Debug.Log("水不够");

        }
        if (resourcesManager.foodInVillage - foodCost < 0)
        {
            canTrain = false;
            Debug.Log("食物不够");
        }
        if (resourcesManager.weaponInVillage - weaponCost < 0)
        {
            canTrain = false;
            Debug.Log("武器不够");
        }
        if (canTrain)
        {
            //找一个村民
            GameObject aVillager = GameObject.FindGameObjectWithTag("Villager");
            //如果找到
            if (aVillager != null)
            {
                //消耗资源并通知刷新
                resourcesManager.waterInVillage -= waterCost;
                resourcesManager.foodInVillage -= foodCost;
                resourcesManager.weaponInVillage -= weaponCost;
                resourcesManager.isVillageChanged = true;

                Vector3 villagerPosition = aVillager.transform.position;
                Destroy(aVillager);
                Instantiate(archer, villagerPosition, archer.transform.rotation);

                resourcesManager.isChangeWorkChanged = true;
            }
            else
                Debug.Log("无业者不够");
        }
    }

    //训练劳工
    public void TrainLaborButton()
    {
        int waterCost = 30, woodCost = 15;
        bool canTrain = true;
        //判断资源是否够
        if (resourcesManager.waterInVillage - waterCost < 0)
        {
            canTrain = false;
            Debug.Log("水不够");

        }
        if (resourcesManager.woodInVillage - woodCost < 0)
        {
            canTrain = false;
            Debug.Log("木材不够");
        }
        if (canTrain)
        {
            //找一个村民
            GameObject aVillager = GameObject.FindGameObjectWithTag("Villager");
            //如果找到
            if (aVillager != null)
            {
                //消耗资源并通知刷新
                resourcesManager.waterInVillage -= waterCost;
                resourcesManager.woodInVillage -= woodCost;
                resourcesManager.isVillageChanged = true;
                //把一个村民改成该职业
                Vector3 villagerPosition = aVillager.transform.position;
                Destroy(aVillager);
                Instantiate(labor, villagerPosition, labor.transform.rotation);

                resourcesManager.isChangeWorkChanged = true;
            }
            else
                Debug.Log("无业者不够");
        }
    }

    //训练采集者
    public void TrainGatherersButton()
    {
        int waterCost = 50;
        bool canTrain = true;
        //判断资源是否够
        if (resourcesManager.waterInVillage - waterCost < 0)
        {
            canTrain = false;
            Debug.Log("水不够");

        }
        if (canTrain)
        {
            //找一个村民
            GameObject aVillager = GameObject.FindGameObjectWithTag("Villager");
            //如果找到
            if (aVillager != null)
            {
                //消耗资源并通知刷新
                resourcesManager.waterInVillage -= waterCost;
                resourcesManager.isVillageChanged = true;
                //把一个村民改成该职业
                Vector3 villagerPosition = aVillager.transform.position;
                Destroy(aVillager);
                Instantiate(gatherers, villagerPosition, gatherers.transform.rotation);

                resourcesManager.isChangeWorkChanged = true;
            }
            else
                Debug.Log("无业者不够");
        }
    }

    #endregion


}
