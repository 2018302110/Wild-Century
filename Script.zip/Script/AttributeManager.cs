﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttributeManager : MonoBehaviour
{
    public int attack;
    public int HP;
    public int addWeight;
    public int gatherRate;
    //食物和水每次消耗量
    public int foodCost;
    public int waterCost;
    //饥饿和口渴时掉血量
    public int hunger;
    public int thirst;
}
