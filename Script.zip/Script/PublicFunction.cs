﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class PublicFunction
{
    // 读档信号
    public static bool canLoad = false;

    // 向目标移动的函数
    public static void Follow(GameObject target, CharacterController characterController, float speed, Transform transform)
    {
        Vector3 walkTo = target.transform.position - transform.position;
        //follower转身
        if (walkTo.magnitude > 0.3)
        {
            transform.forward = walkTo;
        }
        //未到达时
        if (walkTo.magnitude > 0.3)
        {
            characterController.Move(walkTo.normalized * Time.deltaTime * speed);
        }
    }

    // 获取鼠标在指定tag物体上的点击位置
    public static Vector3 GetMouseHitPoint(Vector3 hitPoint, string objectTag)
    {
        //鼠标左键
        if (Input.GetMouseButtonDown(0))
        {
            //所有射线检测到的物体
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit[] hitInfo = Physics.RaycastAll(ray);
            //检测到
            if (hitInfo.Length > 0)
            {
                foreach (RaycastHit hit in hitInfo)
                {
                    //如果找到地面
                    if (hit.collider.CompareTag(objectTag))
                    {
                        return hit.point;
                    }
                }
            }
        }
        return hitPoint;
    }

    // 是否点击到此标签物体
    public static bool IsGetMouseHit(string objectTag)
    {
        //鼠标左键
        if (Input.GetMouseButtonDown(0))
        {
            //所有射线检测到的物体
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit[] hitInfo = Physics.RaycastAll(ray);
            //检测到
            if (hitInfo.Length > 0)
            {
                foreach (RaycastHit hit in hitInfo)
                {
                    //如果找到地面
                    if (hit.collider.CompareTag(objectTag))
                    {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    // 是村民
    public static bool IsVillager(GameObject gameObject)
    {
        if (gameObject != null)
        {
            //根据tag判断
            if (gameObject.CompareTag("Villager") || gameObject.CompareTag("AxeSolider") || gameObject.CompareTag("Archer") || gameObject.CompareTag("Labor") || gameObject.CompareTag("Gatherers"))
                return true;
        }
        return false;
    }

    // 是资源
    public static bool IsResource(GameObject gameObject)
    {
        if (gameObject != null)
        {
            if (gameObject.CompareTag("food") || gameObject.CompareTag("water") || gameObject.CompareTag("wood") || gameObject.CompareTag("weapon"))
                return true;
        }
        return false;
    }

    // 是建筑
    public static bool IsBuilding(GameObject gameObject)
    {
        if (gameObject != null)
        {
            if (gameObject.CompareTag("SmallHouse") || gameObject.CompareTag("MediumHouse") || gameObject.CompareTag("BigHouse") || gameObject.CompareTag("SmallStore") || gameObject.CompareTag("BigStore"))
                return true;
        }
        return false;
    }

    // 播放音效
    public static void PlayAudio(GameObject gameObject,AudioClip clip)
    {
        AudioSource audio = gameObject.GetComponent<AudioSource>();
        if (audio == null)
        {
            audio = gameObject.AddComponent<AudioSource>();
        }
        audio.clip = clip;
        audio.Play();
    }

}
