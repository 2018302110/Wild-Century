﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackToLeader : MonoBehaviour
{
    public GameObject Leader;
    Vector3 offset = new Vector3(0,45,-25);

    public void BackToLeaderButton()
    {
        transform.position = Leader.transform.position + offset;
    }
}
