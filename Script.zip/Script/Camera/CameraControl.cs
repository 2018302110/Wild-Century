﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class CameraControl : MonoBehaviour
{
    public float sensitivityMouse0 = 4f;
    public float sensitivetyMouseWheel = 400f;
    void Update()
    {
        /*//滚轮实现镜头缩进和拉远
        if (Input.GetAxis("Mouse ScrollWheel") != 0)
        {
            this.GetComponent<Camera>().fieldOfView -= Input.GetAxis("Mouse ScrollWheel") * sensitivetyMouseWheel;
        }
        */
        // 滚轮实现镜头升降
        if (Input.GetAxis("Mouse ScrollWheel") != 0)
        {
            transform.position -= new Vector3(0, Input.GetAxis("Mouse ScrollWheel") * sensitivetyMouseWheel, 0);
            // 禁止穿地
            if (transform.position.y < 3)
                transform.position = new Vector3(transform.position.x, 3, transform.position.z);
        }
        // 如果鼠标不在UI上，右键拖动镜头
        if (Input.GetMouseButton(1) && !EventSystem.current.IsPointerOverGameObject())
        {

            transform.Translate(Vector3.left * Input.GetAxis("Mouse X") * sensitivityMouse0);
            transform.Translate(Vector3.down * Input.GetAxis("Mouse Y") * sensitivityMouse0);
        }

    }
}
