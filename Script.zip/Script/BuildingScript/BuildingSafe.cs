﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuildingSafe : MonoBehaviour
{
    public bool isOnGround = false;
    ResourcesManager resourcesManager;

    private void Start()
    {
        // 资源管理类在地面上
        resourcesManager = GameObject.FindGameObjectWithTag("Ground").GetComponent<ResourcesManager>();
    }

    private void Update()
    {
        if(isOnGround&& transform.position.y > 0.1)
                transform.position = new Vector3(transform.position.x, 0, transform.position.z);
    }

    //碰到地面前碰到其它碰撞体
    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.CompareTag("Ground"))
        {
            isOnGround = true;
        }
        if(!isOnGround)
        {
            Destroy(gameObject);
            ReturnMoney();
            Debug.Log("非法建筑");
        }
    }

    void ReturnMoney()
    {
        int buildingWoodCost = GetComponent<BuildingCost>().buildingWoodCost;
        resourcesManager.woodInVillage += buildingWoodCost;        
    }
}
