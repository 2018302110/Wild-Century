﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VillagerSpawn : MonoBehaviour
{
    // 最大普通村民数
    int maxVillager=80;

    Vector3 spawnPosition;
    int villagerNum;
    // 生成速率
    public float spawnRate;
    // 相对建筑偏移量
    [SerializeField] Vector3 offset;
    [SerializeField] GameObject villagerToSpawn;

    private void Start()
    {
        InvokeRepeating("SpawnVillager", spawnRate, spawnRate);
    }

    void SpawnVillager()
    {
        // 普通村民数量
        villagerNum= GameObject.FindGameObjectsWithTag("Villager").Length;

        if (villagerNum <= maxVillager)
        {
            spawnPosition = transform.position + offset;
            Instantiate(villagerToSpawn, spawnPosition, villagerToSpawn.transform.rotation);
        }
        else
        {
            Debug.Log("村民已满");
        }
    }
}
