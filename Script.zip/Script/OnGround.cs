﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OnGround : MonoBehaviour
{

    float lower = 0.6f;
    float higher = 0f;

    void Update()
    {
        if (transform.position.y > lower)
        {
            transform.position = Vector3.Lerp(transform.position,new Vector3(transform.position.x, 0.5f, transform.position.z),0.1f);
        }
        if (transform.position.y < higher)
        {
            transform.position = Vector3.Lerp(transform.position, new Vector3(transform.position.x, 0.5f, transform.position.z), 0.1f);
        }
    }
}
