﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuitButton : MonoBehaviour
{
    [SerializeField] AudioClip click;
    public void OnQuitButton()
    {
        PublicFunction.PlayAudio(this.gameObject, click);
        Application.Quit();
    }
}
