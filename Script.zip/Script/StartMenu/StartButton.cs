﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StartButton : MonoBehaviour
{

    [SerializeField] AudioClip click;
    public void StartGame()
    {
        PublicFunction.PlayAudio(this.gameObject, click);
        SceneManager.LoadScene("GameScene");
    }

}
