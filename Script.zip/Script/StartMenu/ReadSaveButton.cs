﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using UnityEngine.SceneManagement;

public class ReadSaveButton : MonoBehaviour
{

    [SerializeField] AudioClip click;
    public void LoadGame()
    {
        PublicFunction.PlayAudio(this.gameObject, click);

        //发出读档信号
        PublicFunction.canLoad = true;

        SceneManager.LoadScene("GameScene");
    }
 
}
