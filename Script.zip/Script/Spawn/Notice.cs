﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Notice : MonoBehaviour
{
    GameObject panel;
    Text text;
    [SerializeField] string _string;

    private void Start()
    {
        panel = GameObject.FindGameObjectWithTag("Notice");
        text = panel.transform.Find("Text").GetComponent<Text>();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Leader"))
        {
            panel.SetActive(true);
            text.text= ("侦察：前方发现" + _string);
            StartCoroutine("SetFalse");
        }
    }

    IEnumerator SetFalse()
    {
        yield return new WaitForSeconds(2);
        panel.SetActive(false);
    }
}
