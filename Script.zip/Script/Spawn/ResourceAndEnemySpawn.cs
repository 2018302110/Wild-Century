﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResourceAndEnemySpawn : MonoBehaviour
{
    // 要生成的物体
    public GameObject objectToSpawn;
    // 生成区域大小
    [SerializeField] float spawnRange;
    // 最大生成数
    [SerializeField] int maxSpawn;
    // 生成数量
    int spawnCount = 0;
    // 随机位置
    float randomX, randomZ;
    Vector3 randomPosition;
    // 生成的所有物体
    GameObject[] spawnGameObjects;

    [HideInInspector] public bool canSpawn = false;
    // 协程是否开启
    bool coroutineHaveStarted = false;
    // 是否已重置
    bool isReset = false;

    private void Start()
    {
        spawnGameObjects = new GameObject[maxSpawn];
    }

    private void Update()
    {
        if (canSpawn && !coroutineHaveStarted)
        {
            TryToSpawn();
        }
        // 离开生成区域且未重置则重置
        if (!isReset && !canSpawn)
        {
            StopCoroutine("StartSpawn");
            coroutineHaveStarted = false;
            spawnCount = 0;
            foreach (GameObject gameObject in spawnGameObjects)
            {
                if (gameObject != null)
                {
                    // 此时怪物不能掉落物品
                    Drop drop = gameObject.GetComponent<Drop>();
                    if (drop != null)
                        drop.canDrop = false;
                    Destroy(gameObject);
                }
            }
            isReset = true;
        }
    }

    void TryToSpawn()
    {
        isReset = false;
        coroutineHaveStarted = true;
        StartCoroutine("StartSpawn");
    }

    IEnumerator StartSpawn()
    {
        // 未达最大值
        while (spawnCount < maxSpawn)
        {
            randomX = Random.Range(-spawnRange, spawnRange);
            randomZ = Random.Range(-spawnRange, spawnRange);
            randomPosition = new Vector3(randomX, 0, randomZ);
            spawnGameObjects[spawnCount] = Instantiate(objectToSpawn, transform.position + randomPosition, objectToSpawn.transform.rotation);
            spawnCount++;
            yield return new WaitForSeconds(0.2f);
        }
    }
}
