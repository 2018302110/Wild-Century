﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gather : MonoBehaviour
{
    // 冲向资源的速度
    public float villageSpeed;
    // 采集速度
    public float gatherRate;
    // 采集量
    public int _gather;

    bool isFindResource, canGather;
    // 协程未开始，避免在Update中开始多个协程
    bool coroutineHaveStarted = false;
    // 子物体
    GameObject villagerNormalFindRange, villagerAttackRange, villagerWarFindRange;

    GameObject resource;
    CharacterController controller;

    ResourcesManager resourcesManager;

    void Start()
    {
        resourcesManager = FindObjectOfType<ResourcesManager>().GetComponent<ResourcesManager>();
        controller = GetComponent<CharacterController>();
        // 从属性管理类中获得采集量
        _gather = GetComponent<AttributeManager>().gatherRate;

        // 获得两种视野范围和攻击范围子物体
        villagerNormalFindRange = transform.Find("VillagerNormalFindRange").gameObject;
        villagerWarFindRange = transform.Find("VillagerWarFindRange").gameObject;
        villagerAttackRange = transform.Find("VillagerAttackRange").gameObject;

    }

    void Update()
    {
        // 如果不在军队或在军队中且要撤退
        if (!GetComponent<FollowLeader>().isInArmy || (GetComponent<FollowLeader>().isInArmy && GetComponent<FollowLeader>().isRetire))
        {
            if (coroutineHaveStarted == true)
            {
                // 取消播放采集动画
                GetComponent<AnimatorControl>().animator.SetBool("isGather", false);
                GetComponent<AnimatorControl>().isGatherChanged = true;
                // 关闭协程
                StopCoroutine("Get");
                coroutineHaveStarted = false;
                GetComponent<FollowLeader>().isGathering = false;
            }
        }
        else
        {
            // 从视野和攻击范围触发器中获得是否发现资源bool值
            if (villagerNormalFindRange.activeSelf)
                isFindResource = villagerNormalFindRange.GetComponent<GatherFindRange>().isFindResource;
            else if (villagerWarFindRange.activeSelf)
                isFindResource = villagerWarFindRange.GetComponent<GatherFindRange>().isFindResource;
            canGather = villagerAttackRange.GetComponent<GatherCanRange>().canGather;

            // 当发现资源时
            if (isFindResource)
            {
                // 获取视野触发器的资源
                if (villagerNormalFindRange.activeSelf)
                    resource = villagerNormalFindRange.GetComponent<GatherFindRange>().resource;
                else if (villagerWarFindRange.activeSelf)
                    resource = villagerWarFindRange.GetComponent<GatherFindRange>().resource;

                // 正在采集，停止跟随
                GetComponent<FollowLeader>().isGathering = true;
                // 如果还不在采集范围且资源未被队友采光
                if (!canGather && resource != null)
                {
                    // 向资源走去
                    PublicFunction.Follow(resource, controller, villageSpeed, transform);
                }
                else
                {
                    // 如果控制采集的协程未启动
                    if (!coroutineHaveStarted)
                    {
                        Gathering(resource);
                    }
                }
            }
            // 找不到资源则未采集，开始跟随
            else
            {
                GetComponent<FollowLeader>().isGathering = false;
            }
        }

    }

    void Gathering(GameObject resource)
    {
        StartCoroutine("Get", resource);
    }

    IEnumerator Get(GameObject resource)
    {
        coroutineHaveStarted = true;

        // 判断资源物体剩下什么资源
        int _haveLeft(GameObject gameObject)
        {
            if (gameObject.GetComponent<ResourceAttribute>().food > 0)
                return 1;
            if (gameObject.GetComponent<ResourceAttribute>().water > 0)
                return 2;
            if (gameObject.GetComponent<ResourceAttribute>().wood > 0)
                return 3;
            if (gameObject.GetComponent<ResourceAttribute>().weapon > 0)
                return 4;
            return 0;
        }

        // 如果资源未被采光
        if (resource != null)
        {
            int haveLeft = _haveLeft(resource);

            bool isHaveWeightLeft = (resourcesManager.currentArmyWeight < (resourcesManager.maxWeight - 4));
            // 如果资源有剩余且军队负重未满
            while (resource != null && haveLeft > 0 && isHaveWeightLeft)
            {
                // 如果自己没被打死
                if (this != null)
                {
                    // 播放采集动画
                    GetComponent<AnimatorControl>().animator.SetBool("isGather", true);
                    GetComponent<AnimatorControl>().isGatherChanged = true;
                    // 获得资源
                    switch (haveLeft)
                    {
                        case 1:
                            resource.GetComponent<ResourceAttribute>().food -= _gather;
                            resourcesManager.foodInArmy += _gather;
                            // 通知数量已改变
                            resourcesManager.isArmyResourceChanged = true;
                            break;
                        case 2:
                            resource.GetComponent<ResourceAttribute>().water -= _gather;
                            resourcesManager.waterInArmy += _gather;
                            // 通知数量已改变
                            resourcesManager.isArmyResourceChanged = true;
                            break;
                        case 3:
                            resource.GetComponent<ResourceAttribute>().wood -= _gather;
                            resourcesManager.woodInArmy += _gather;
                            // 通知数量已改变
                            resourcesManager.isArmyResourceChanged = true;
                            break;
                        case 4:
                            resource.GetComponent<ResourceAttribute>().weapon -= _gather;
                            resourcesManager.weaponInArmy += _gather;
                            // 通知数量已改变
                            resourcesManager.isArmyResourceChanged = true;
                            break;
                    }
                }
                // 等待一个前摇
                yield return new WaitForSeconds(gatherRate);
                if (resource != null)
                {
                    // 更新剩余资源
                    haveLeft = _haveLeft(resource);
                }
            }
            if (isHaveWeightLeft)
            {
                // 销毁资源
                Destroy(resource);
                Debug.Log("采集完成");
            }
            // 取消播放采集动画
            GetComponent<AnimatorControl>().animator.SetBool("isGather", false);
            GetComponent<AnimatorControl>().isGatherChanged = true;
        }

        // 更改视野和攻击范围都无资源
        if (villagerNormalFindRange.activeSelf)
            villagerNormalFindRange.GetComponent<GatherFindRange>().isFindResource = false;
        else if (villagerWarFindRange.activeSelf)
            villagerWarFindRange.GetComponent<GatherFindRange>().isFindResource = false;
        villagerAttackRange.GetComponent<GatherCanRange>().canGather = false;
        // 改为协程未启动
        coroutineHaveStarted = false;

        yield return null;
    }
}
