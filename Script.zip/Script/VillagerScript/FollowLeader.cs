﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowLeader : MonoBehaviour
{
    //跟随的速度
    public float speed;
    public bool isFighting = false;
    public bool isGathering = false;
    public bool isInArmy = false;
    public bool followed = false;
    public bool isRetire = false;
    GameObject leader;
    CharacterController controller;


    private void Start()
    {
        controller = GetComponent<CharacterController>();
        leader = FindObjectOfType<LeaderMove>().gameObject;
    }

    void Update()
    {
        //在军队中没有战斗和采集或需要撤退时跟随
        if (!isFighting &&!isGathering&& isInArmy && !followed)
        {
            PublicFunction.Follow(leader, controller, speed, transform);
        }
        else if (isRetire && isInArmy && !followed)
            PublicFunction.Follow(leader, controller, speed, transform);
    }
}
