﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


//劳工，采集者逃避敌人
public class EludeEnemy : MonoBehaviour
{

    //逃离敌人的速度
    public float villageSpeed;

    bool isFind;

    //子物体
    GameObject villagerNormalFindRange,  villagerWarFindRange;

    GameObject enemy;
    CharacterController controller;

    void Start()
    {
        controller = GetComponent<CharacterController>();

        //获得两种视野范围子物体
        villagerNormalFindRange = transform.Find("VillagerNormalFindRange").gameObject;
        villagerWarFindRange = transform.Find("VillagerWarFindRange").gameObject;

        //从激活的视野范围获得是否找到敌人的bool值
        if (villagerNormalFindRange.activeSelf)
        {
            isFind = villagerNormalFindRange.GetComponent<VillagerFindRange>().isFind;
        }
        else if (villagerWarFindRange.activeSelf)
        {
            isFind = villagerWarFindRange.GetComponent<VillagerFindRange>().isFind;
        }

        //从激活的视野范围中获得发现的敌人
        if (villagerNormalFindRange.activeSelf)
            enemy = villagerNormalFindRange.GetComponent<VillagerFindRange>().enemy;
        else if (villagerWarFindRange.activeSelf)
            enemy = villagerWarFindRange.GetComponent<VillagerFindRange>().enemy;
    }

    void Update()
    {
        if(isFind&&enemy!=null)
        {
            //逃跑路线
            Vector3 eludeWay= transform.position - enemy.transform.position;
            transform.forward = eludeWay;
            controller.Move(eludeWay.normalized * Time.deltaTime * villageSpeed);
        }

        //从视野和攻击范围触发器中获得新值
        if (villagerNormalFindRange.activeSelf)
            isFind = villagerNormalFindRange.GetComponent<VillagerFindRange>().isFind;
        else if (villagerWarFindRange.activeSelf)
            isFind = villagerWarFindRange.GetComponent<VillagerFindRange>().isFind;


        //获取视野触发器的敌人
        if (isFind)
        {
            if (villagerNormalFindRange.activeSelf)
                enemy = villagerNormalFindRange.GetComponent<VillagerFindRange>().enemy;
            else if (villagerWarFindRange.activeSelf)
                enemy = villagerWarFindRange.GetComponent<VillagerFindRange>().enemy;
        }

    }
}
