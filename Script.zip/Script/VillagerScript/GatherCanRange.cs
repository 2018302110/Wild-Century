﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GatherCanRange : MonoBehaviour
{
    public bool canGather=false;


    private void OnTriggerStay(Collider other)
    {
        if (PublicFunction.IsResource(other.gameObject))
            canGather = true;
    }

    private void OnTriggerExit(Collider other)
    {
        if (PublicFunction.IsResource(other.gameObject))
            canGather = false;
    }
}
