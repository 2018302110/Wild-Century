﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VillagerFindRange : MonoBehaviour
{
    public bool isFind=false;
    public GameObject enemy=null;

    private void OnTriggerStay(Collider other)
    {
        if (other.gameObject.CompareTag("Enemy"))
        {
            isFind = true;
            enemy = other.gameObject;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.CompareTag("Enemy"))
            isFind = false;
    }
}
