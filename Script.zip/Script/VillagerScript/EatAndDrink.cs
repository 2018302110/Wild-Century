﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EatAndDrink : MonoBehaviour
{
    //食物和水每次消耗量
    int foodCost;
    int waterCost;

    //饥饿和口渴时掉血量
    int hunger;
    int thirst;

    //每次消耗间隔时间
    public float consumeTime ;

    //是否在队伍中
    public bool isInArmy;

    AttributeManager attributeManager;
    ResourcesManager resourcesManager;
    //协程是否开始
    bool coroutineHaveStarted;

    void Start()
    {
        coroutineHaveStarted = false;

        attributeManager = GetComponent<AttributeManager>();
        foodCost = attributeManager.foodCost;
        waterCost = attributeManager.waterCost;
        hunger = attributeManager.hunger;
        thirst = attributeManager.thirst;

        isInArmy = GetComponent<FollowLeader>().isInArmy;
        //资源管理类在地面上
        resourcesManager = GameObject.FindGameObjectWithTag("Ground").GetComponent<ResourcesManager>();
    }



    void Update()
    {
        //在军队中
        if (isInArmy)
        {
            //如果协程未开始
            if (!coroutineHaveStarted)
            {
                StartCoroutine(Consume());
                coroutineHaveStarted = true;
            }
        }
    }

    IEnumerator Consume()
    {
        //等待一个消耗周期
        yield return new WaitForSeconds(consumeTime);
        if (isInArmy)
        {
            //消耗食物和水,不足时掉血
            GameObject.FindGameObjectWithTag("Ground").GetComponent<ResourcesManager>().foodInArmy -= foodCost;
            if (GameObject.FindGameObjectWithTag("Ground").GetComponent<ResourcesManager>().foodInArmy <= 0)
                GetComponent<AttributeManager>().HP -= hunger;
            GameObject.FindGameObjectWithTag("Ground").GetComponent<ResourcesManager>().waterInArmy -= waterCost;
            if (GameObject.FindGameObjectWithTag("Ground").GetComponent<ResourcesManager>().waterInArmy <= 0)
                GetComponent<AttributeManager>().HP -= thirst;

            //通知数量已改变
            resourcesManager.isArmyResourceChanged = true;
            resourcesManager.isVillageChanged = true;
        }
        //协程结束
        coroutineHaveStarted = false;

    }
}
