﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FindEnemy : MonoBehaviour
{
    //冲向敌人的速度
    public float villageSpeed;
    //攻击速度
    public float attackRate;
    //攻击力
    int _attack;

    bool isFind, canAttack;
    //协程未开始，避免在Update中开始多个协程
    bool coroutineHaveStarted = false;
    //子物体
    GameObject villagerNormalFindRange, villagerAttackRange, villagerWarFindRange;
    GameObject enemy;
    CharacterController controller;

    void Start()
    {
        controller = GetComponent<CharacterController>();
        //从属性管理类中获得攻击力
        _attack = GetComponent<AttributeManager>().attack;

        //获得两种视野范围和攻击范围子物体
        villagerNormalFindRange = transform.Find("VillagerNormalFindRange").gameObject;
        villagerWarFindRange = transform.Find("VillagerWarFindRange").gameObject;
        villagerAttackRange = transform.Find("VillagerAttackRange").gameObject;
    }

    void Update()
    {
        //如果在军队中并且要撤退
        if (GetComponent<FollowLeader>().isInArmy && GetComponent<FollowLeader>().isRetire)
        {
            if (coroutineHaveStarted == true)
            {
                //取消播放战斗动画
                GetComponent<AnimatorControl>().animator.SetBool("isFight", false);
                GetComponent<AnimatorControl>().isFightChanged = true;
                //关闭协程
                StopCoroutine("Hurt");
                coroutineHaveStarted = false;
                GetComponent<FollowLeader>().isFighting = false;
            }
        }
        else
        {
            //从视野和攻击范围触发器中获得新值
            if (villagerNormalFindRange.activeSelf)
                isFind = villagerNormalFindRange.GetComponent<VillagerFindRange>().isFind;
            else if (villagerWarFindRange.activeSelf)
                isFind = villagerWarFindRange.GetComponent<VillagerFindRange>().isFind;
            canAttack = villagerAttackRange.GetComponent<VillagerAttackRange>().canAttack;

            //当发现敌人时
            if (isFind)
            {
                //获取视野触发器的敌人
                if (villagerNormalFindRange.activeSelf)
                    enemy = villagerNormalFindRange.GetComponent<VillagerFindRange>().enemy;
                else if (villagerWarFindRange.activeSelf)
                    enemy = villagerWarFindRange.GetComponent<VillagerFindRange>().enemy;

                //正在战斗，停止跟随
                GetComponent<FollowLeader>().isFighting = true;
                //如果还不在攻击范围且敌人未被队友消灭
                if (!canAttack && enemy != null)
                {
                    //向敌人走去
                    PublicFunction.Follow(enemy, controller, villageSpeed, transform);
                }
                else
                {
                    //如果控制战斗的协程未启动
                    if (!coroutineHaveStarted)
                    {
                        Fighting(enemy);
                    }
                }
            }
            //找不到敌人则未战斗，开始跟随
            else
            {
                GetComponent<FollowLeader>().isFighting = false;
            }
        }

    }

    void Fighting(GameObject enemy)
    {
        StartCoroutine("Hurt",enemy);
    }

    IEnumerator Hurt(GameObject enemy)
    {
        coroutineHaveStarted = true;
        //如果敌人未被消灭
        if (enemy != null)
        {
            //如果敌人血量大于0
            while (enemy!=null&&enemy.GetComponent<AttributeManager>().HP > 0)
            {
                //如果自己没被打死
                if (this != null)
                {
                    //播放战斗动画
                    GetComponent<AnimatorControl>().animator.SetBool("isFight", true);
                    GetComponent<AnimatorControl>().isFightChanged = true;
                    //敌人减血
                    enemy.GetComponent<AttributeManager>().HP -= _attack;
                }
                //等待一个前摇
                yield return new WaitForSeconds(attackRate);
            }
            //销毁敌人
            Destroy(enemy);
            Debug.Log("战斗胜利");
            //取消播放战斗动画
            GetComponent<AnimatorControl>().animator.SetBool("isFight", false);
            GetComponent<AnimatorControl>().isFightChanged = true;
        }

        //更改视野和攻击范围都无敌人
        if (villagerNormalFindRange.activeSelf)
            villagerNormalFindRange.GetComponent<VillagerFindRange>().isFind = false;
        else if (villagerWarFindRange.activeSelf)
            villagerWarFindRange.GetComponent<VillagerFindRange>().isFind = false;
        villagerAttackRange.GetComponent<VillagerAttackRange>().canAttack = false;
        //协程未启动
        coroutineHaveStarted = false;

        yield return null ;
    }
}
