﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimatorControl: MonoBehaviour
{
    public Animator animator;
    public bool isFightChanged = false;
    public bool isGatherChanged = false;
    public bool isFight = false;
    public bool isGather = false;
    Vector3 oldPosition;
    float speed;

    void Start()
    {
        oldPosition = transform.position;
    }

    void Update()
    {
        Vector3 newPosition = transform.position;
        Vector3 move = newPosition - oldPosition;
        speed = move.magnitude / Time.deltaTime;
        //防止在走跑间持续切换
        int roundSpeed = Mathf.RoundToInt(speed);
        oldPosition = newPosition;
        animator.SetFloat("speed", roundSpeed);
        //改变时再重新赋值(可使没有采集或战斗动画的角色也用此类）
        if (isFightChanged)
        {
            animator.SetBool("isFight", isFight);
            isFightChanged = false;
        }
        if (isGatherChanged)
        {
            animator.SetBool("isGather", isGather);
            isGatherChanged = false;
        }
    }
}
