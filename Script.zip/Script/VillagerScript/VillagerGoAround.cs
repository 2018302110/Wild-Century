﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VillagerGoAround : MonoBehaviour
{

    float villagerWalkSpeed;
    CharacterController controller;
    Vector3 RandomVector;
    bool isFighting, isInArmy, followed, isGathering;

    void Start()
    {
        float changeDirectionRate = Random.Range(3, 7);
        controller = gameObject.GetComponent<CharacterController>();
        InvokeRepeating("GoAround", 0.5f, changeDirectionRate);
    }

    void Update()
    {
        //如果没有被挤到半空中的话（Move函数会妨碍OnGround的执行）
        if (transform.position.y < 0.6f)
        {
            isFighting = GetComponent<FollowLeader>().isFighting;
            isInArmy = GetComponent<FollowLeader>().isInArmy;
            followed = GetComponent<FollowLeader>().followed;
            isGathering = GetComponent<FollowLeader>().isGathering;

            //没有战斗和采集且在军队且已在范围内就散步
            if (!isFighting && !isGathering && isInArmy && followed)
            {
                villagerWalkSpeed = 1f;
                controller.Move(RandomVector.normalized * villagerWalkSpeed * Time.deltaTime);
                if (RandomVector.magnitude > 0.1)
                    transform.forward = Vector3.Lerp(transform.forward, RandomVector, 0.05f);
            }
            //没有战斗和采集且没有在军队中
            if (!isFighting &&!isGathering&& !isInArmy)
            {
                villagerWalkSpeed = 1f;
                controller.Move(RandomVector.normalized * villagerWalkSpeed * Time.deltaTime);
                if (RandomVector.magnitude > 0.1)
                    transform.forward = Vector3.Lerp(transform.forward, RandomVector, 0.05f);
            }
        }
    }

    //碰到东西改变方向
    private void OnCollisionEnter(Collision collision)
    {
        GoAround();
    }


    public void GoAround()
    {
        //获得一个随机方向
        float x = Random.Range(-10, 10);
        float z = Random.Range(-10, 10);
        RandomVector = new Vector3(x, 0, z);
    }
}
