﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VillagerAttackRange : MonoBehaviour
{

    public bool canAttack=false;

    private void OnTriggerStay(Collider other)
    {
        if (other.gameObject.CompareTag("Enemy"))
            canAttack = true;
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.CompareTag("Enemy"))
            canAttack = false;
    }
}
