﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GatherFindRange : MonoBehaviour
{
    public bool isFindResource = false;
    public GameObject resource;

    private void OnTriggerStay(Collider other)
    {
        if (PublicFunction.IsResource(other.gameObject))             //如果是资源
            if (!GetComponent<VillagerFindRange>().isFind)   //如果没有敌人
            {
                isFindResource = true;                         //发现资源
                resource = other.gameObject;             //资源物体
            }
    }

    private void OnTriggerExit(Collider other)
    {
        if (PublicFunction.IsResource(other.gameObject))            
            isFindResource = false;
    }
}
