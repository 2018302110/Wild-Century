﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResourceAttribute : MonoBehaviour
{
    public int food;
    public int water;
    public int wood;
    public int weapon;
}
