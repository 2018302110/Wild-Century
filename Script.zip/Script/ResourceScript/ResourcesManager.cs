﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ResourcesManager : MonoBehaviour
{

    #region 随军物资
    public int foodInArmy;
    public int waterInArmy;
    public int woodInArmy;
    public int weaponInArmy;
    public int currentArmyWeight;
    // 军队负重量
    [SerializeField] int defoultWeight;
    public int maxWeight;
    #endregion

    #region 仓库物资
    public int foodInVillage;
    public int waterInVillage;
    public int woodInVillage;
    public int weaponInVillage;
    public int currentStoreWeight;
    // 仓库容量
    public int maxWeightStore;
    #endregion

    #region 单个物质重量
    public int foodWeight;
    public int waterWeight;
    public int woodWeight;
    public int weaponWeight;
    #endregion

    #region 随军物质数值显示
    [SerializeField] Text armyFoodnum;
    [SerializeField] Text armyWaternum;
    [SerializeField] Text armyWeightnum;
    // 随军物质Slider
    [SerializeField] Slider armyFoodSlider;
    [SerializeField] Slider armyWaterSlider;
    [SerializeField] Slider armyWeightSlider;
    #endregion

    #region 祭坛数据面板数据
    [SerializeField] Text altarArmyFoodnum;
    [SerializeField] Text altarArmyWaternum;
    [SerializeField] Text altarArmyWoodnum;
    [SerializeField] Text altarArmyWeaponnum;

    public Text altarVillageFoodnum;
    public Text altarVillageWaternum;
    public Text altarVillageWoodnum;
    public Text altarVillageWeaponnum;
    public Text altarVillageWeightnum;
    public Slider altarVillageWeightSlider;

    [SerializeField] Text altarHousenum;
    [SerializeField] Text altarStorenum;
    [SerializeField] Text altarBirthRate;
    #endregion

    #region 转职数据面板数据
    [SerializeField] Text villagernum;
    [SerializeField] Text axeSolidernum;
    [SerializeField] Text archernum;
    [SerializeField] Text labornum;
    [SerializeField] Text gatherersnum;

    #endregion

    #region 出征队伍面板
    // 人员数据
    public Text villagerInArmy;
    public Slider villagerSlider;
    public Text axeSoliderInArmy;
    public Slider axeSoliderSlider;
    public Text archerInArmy;
    public Slider archerSlider;
    public Text laborInArmy;
    public Slider laborSlider;
    public Text gatherersInArmy;
    public Slider gatherersSlider;

    // 物资数据
    public Text foodInTroop;
    public Slider foodInTroopSlider;
    public Text waterInTroop;
    public Slider waterInTroopSlider;
    // 最大人数UI
    public int maxPeopleNum;
    public Text maxPeopleNumText;
    // 消耗，承重，采集
    public Text foodCostRate;
    public Text waterCostRate;
    public Text weightNum;
    public Text gatherRate;
    #endregion

    #region 数量改变
    public bool isArmyResourceChanged = false;
    public bool isVillageChanged = false;
    public bool isChangeWorkChanged = false;
    public bool isChangeTroops = false;
    #endregion


    private void Start()
    {
        maxWeight = defoultWeight;
        // num的显示
        armyFoodnum.text = foodInArmy.ToString();
        armyWaternum.text = waterInArmy.ToString();
        // 计算重量
        int weight = foodInArmy * foodWeight + waterInArmy * waterWeight + woodInArmy * woodWeight + weaponInArmy * weaponWeight;
        armyWeightnum.text = weight.ToString();

        // Slider的设置
        armyFoodSlider.maxValue = maxWeight / foodWeight;
        armyFoodSlider.value = foodInArmy;
        armyWaterSlider.maxValue = maxWeight / waterWeight;
        armyWaterSlider.value = waterInArmy;
        armyWeightSlider.maxValue = maxWeight;
        armyWeightSlider.value = weight;
        // 滑动条不可拖动
        armyFoodSlider.interactable = false;
        armyWaterSlider.interactable = false;
        armyWeightSlider.interactable = false;


    }

    private void Update()
    {
        // 军队资源数目改变
        if (isArmyResourceChanged)
        {
            UpdateArmyResource();
            isArmyResourceChanged = false;
        }
        // 村庄资源数目改变
        if (isVillageChanged)
        {
            UpdateVillageResource();
            isVillageChanged = false;
        }
        // 转职面板数据改变
        if (isChangeWorkChanged)
        {
            UpdateChangeWorkPanel();
            isChangeWorkChanged = false;
        }
        // 队伍面板改变
        if (isChangeTroops)
        {
            UpdateTroopsPanel();
            isChangeTroops = false;
        }
    }

    #region 更新ArmyResource的UI
    void UpdateArmyResource()
    {
        // 处理超出范围
        ArmyResourceInRange();
        armyFoodnum.text = foodInArmy.ToString();
        armyFoodSlider.value = foodInArmy;
        armyWaternum.text = waterInArmy.ToString();
        armyWaterSlider.value = waterInArmy;
        // 计算重量
        int weight = foodInArmy * foodWeight + waterInArmy * waterWeight + woodInArmy * woodWeight + weaponInArmy * weaponWeight;
        currentArmyWeight = weight;
        armyWeightnum.text = weight.ToString();
        armyWeightSlider.value = weight;
    }

    void ArmyResourceInRange()
    {
        if (foodInArmy < 0)
        {
            Debug.Log("食物不足");
            foodInArmy = 0;
        }
        if (foodInArmy > (maxWeight - waterInArmy * waterWeight - woodInArmy * woodWeight - weaponInArmy * weaponWeight) / foodWeight)
        {
            Debug.Log("食物装不下了");
            foodInArmy = (maxWeight - waterInArmy * waterWeight - woodInArmy * woodWeight - weaponInArmy * weaponWeight) / foodWeight;
        }
        if (waterInArmy < 0)
        {
            Debug.Log("水不足");
            waterInArmy = 0;
        }
        if (waterInArmy > (maxWeight - foodInArmy * foodWeight - woodInArmy * woodWeight - weaponInArmy * weaponWeight) / waterWeight)
        {
            Debug.Log("水装不下了");
            waterInArmy = (maxWeight - foodInArmy * foodWeight - woodInArmy * woodWeight - weaponInArmy * weaponWeight) / waterWeight;
        }
        if (woodInArmy > (maxWeight - foodInArmy * foodWeight - waterInArmy * waterWeight - weaponInArmy * weaponWeight) / woodWeight)
        {
            Debug.Log("木材装不下了");
            woodInArmy = (maxWeight - foodInArmy * foodWeight - waterInArmy * waterWeight - weaponInArmy * weaponWeight) / woodWeight;
        }
        if (weaponInArmy > (maxWeight - foodInArmy * foodWeight - woodInArmy * woodWeight - waterInArmy * waterWeight) / weaponWeight)
        {
            Debug.Log("武器装不下了");
            weaponInArmy = (maxWeight - foodInArmy * foodWeight - woodInArmy * woodWeight - waterInArmy * waterWeight) / weaponWeight;
        }

    }
    #endregion

    #region 更新VillageResource的UI
    void UpdateVillageResource()
    {
        // 处理超出范围
        VillageInRange();

        // 军队物资数据
        altarArmyFoodnum.text = foodInArmy.ToString();
        altarArmyWaternum.text = waterInArmy.ToString();
        altarArmyWoodnum.text = woodInArmy.ToString();
        altarArmyWeaponnum.text = weaponInArmy.ToString();
        // 仓库物资数据
        altarVillageFoodnum.text = foodInVillage.ToString();
        altarVillageWaternum.text = waterInVillage.ToString();
        altarVillageWoodnum.text = woodInVillage.ToString();
        altarVillageWeaponnum.text = weaponInVillage.ToString();
        // 计算重量
        int weight = foodInVillage * foodWeight + waterInVillage * waterWeight + woodInVillage * woodWeight + weaponInVillage * weaponWeight;
        currentStoreWeight = weight;
        altarVillageWeightnum.text = weight.ToString();
        // 建筑数量
        int smallHouseNum = GameObject.FindGameObjectsWithTag("SmallHouse").Length;
        int mediumHouseNum = GameObject.FindGameObjectsWithTag("MediumHouse").Length;
        int bigHouseNum = GameObject.FindGameObjectsWithTag("BigHouse").Length;
        int smallStoreNum = GameObject.FindGameObjectsWithTag("SmallStore").Length;
        int bigStoreNum = GameObject.FindGameObjectsWithTag("BigStore").Length;
        // 小仓库容量600，大仓库容量2000
        maxWeightStore = smallStoreNum * 600 + bigStoreNum * 2000;

        // 仓库容量
        altarVillageWeightSlider.maxValue = maxWeightStore;
        altarVillageWeightSlider.value = weight;
        altarVillageWeightSlider.interactable = false;

        // 房子数量
        int houseNum = smallHouseNum+mediumHouseNum+bigHouseNum;
        altarHousenum.text = houseNum.ToString();
        // 仓库数量
        int storeNum = smallStoreNum+bigStoreNum;
        altarStorenum.text = storeNum.ToString();
        // 出生速度/分钟
        int birthRate = smallHouseNum + mediumHouseNum*2 + bigHouseNum*4;
        altarBirthRate.text = birthRate.ToString();
    }

    void VillageInRange()
    {
        if (foodInVillage < 0)
        {
            Debug.Log("仓库食物不足");
            foodInVillage = 0;
        }
        if (foodInVillage > (maxWeightStore - waterInVillage * waterWeight - woodInVillage * woodWeight - weaponInVillage * weaponWeight) / foodWeight)
        {
            Debug.Log("食物装不下仓库了");
            foodInArmy = (maxWeightStore - waterInVillage * waterWeight - woodInVillage * woodWeight - weaponInVillage * weaponWeight) / foodWeight;
        }
        if (waterInVillage < 0)
        {
            Debug.Log("仓库水不足");
            waterInVillage = 0;
        }
        if (waterInVillage > (maxWeightStore - foodInVillage * foodWeight - woodInVillage * woodWeight - weaponInVillage * weaponWeight) / waterWeight)
        {
            Debug.Log("水装不下仓库了");
            waterInArmy = (maxWeightStore - foodInVillage * foodWeight - woodInVillage * woodWeight - weaponInVillage * weaponWeight) / waterWeight;
        }
        if (woodInVillage < 0)
        {
            Debug.Log("仓库木材不足");
            woodInVillage = 0;
        }
        if (woodInVillage > (maxWeightStore - waterInVillage * waterWeight - foodInVillage * foodWeight - weaponInVillage * weaponWeight) / woodWeight)
        {
            Debug.Log("木材装不下仓库了");
            foodInArmy = (maxWeightStore - waterInVillage * waterWeight - foodInVillage * foodWeight - weaponInVillage * weaponWeight) / woodWeight;
        }
        if (weaponInVillage < 0)
        {
            Debug.Log("仓库武器不足");
            weaponInVillage = 0;
        }
        if (weaponInVillage > (maxWeightStore - waterInVillage * waterWeight - woodInVillage * woodWeight - foodInVillage * foodWeight) / weaponWeight)
        {
            Debug.Log("武器装不下仓库了");
            foodInArmy = (maxWeightStore - waterInVillage * waterWeight - woodInVillage * woodWeight - foodInVillage * foodWeight) / weaponWeight;
        }
    }
    #endregion

    #region 更新ChangeWorkPanel的UI
    void UpdateChangeWorkPanel()
    {
        villagernum.text = GameObject.FindGameObjectsWithTag("Villager").Length.ToString();
        axeSolidernum.text = GameObject.FindGameObjectsWithTag("AxeSolider").Length.ToString();
        archernum.text = GameObject.FindGameObjectsWithTag("Archer").Length.ToString();
        labornum.text = GameObject.FindGameObjectsWithTag("Labor").Length.ToString();
        gatherersnum.text = GameObject.FindGameObjectsWithTag("Gatherers").Length.ToString();
    }
    #endregion

    // 一键放入按钮
    public void PutInStore()
    {
        foodInVillage += foodInArmy;
        waterInVillage += waterInArmy;
        woodInVillage += woodInArmy;
        weaponInVillage += weaponInArmy;
        isVillageChanged = true;

        foodInArmy = 0;
        waterInArmy = 0;
        woodInArmy = 0;
        weaponInArmy = 0;
        isArmyResourceChanged = true;
    }

    #region 更新出征队伍UI
    void UpdateTroopsPanel()
    {
        maxPeopleNumText.text = maxPeopleNum.ToString();
        // 所有人
        GameObject[] allVillager = GameObject.FindGameObjectsWithTag("Villager");
        GameObject[] allAxeSolider = GameObject.FindGameObjectsWithTag("AxeSolider");
        GameObject[] allArcher = GameObject.FindGameObjectsWithTag("Archer");
        GameObject[] allLabor = GameObject.FindGameObjectsWithTag("Labor");
        GameObject[] allGatherers = GameObject.FindGameObjectsWithTag("Gatherers");
        // 所有职业属性
        AttributeManager villagerAttribute = GameObject.FindGameObjectWithTag("Villager")?.GetComponent<AttributeManager>();
        AttributeManager axeSoliderAttribute = GameObject.FindGameObjectWithTag("AxeSolider")?.GetComponent<AttributeManager>();
        AttributeManager archerAttribute = GameObject.FindGameObjectWithTag("Archer")?.GetComponent<AttributeManager>();
        AttributeManager laborAttribute = GameObject.FindGameObjectWithTag("Labor")?.GetComponent<AttributeManager>();
        AttributeManager gatherersAttribute = GameObject.FindGameObjectWithTag("Gatherers")?.GetComponent<AttributeManager>();
        // 设置可选出征人物Slider最大值
        villagerSlider.maxValue = allVillager.Length;
        axeSoliderSlider.maxValue = allAxeSolider.Length;
        archerSlider.maxValue = allArcher.Length;
        laborSlider.maxValue = allLabor.Length;
        gatherersSlider.maxValue = allGatherers.Length;

        // 控制队伍人数及食物和水
        TroopsInRange();

        // 显示队伍中数量
        villagerInArmy.text = Mathf.RoundToInt(villagerSlider.value).ToString();
        axeSoliderInArmy.text = Mathf.RoundToInt(axeSoliderSlider.value).ToString();
        archerInArmy.text = Mathf.RoundToInt(archerSlider.value).ToString();
        laborInArmy.text = Mathf.RoundToInt(laborSlider.value).ToString();
        gatherersInArmy.text = Mathf.RoundToInt(gatherersSlider.value).ToString();


        int countNum(int vil, int axe, int arc, int lab, int gat)
        {
            int result;
            result = (int)(Mathf.RoundToInt(villagerSlider.value) * vil + Mathf.RoundToInt(axeSoliderSlider.value) * axe + Mathf.RoundToInt(archerSlider.value) * arc + Mathf.RoundToInt(laborSlider.value) * lab + Mathf.RoundToInt(gatherersSlider.value) * gat);
            return result;
        }

        // 计算此队伍食物，水消耗，负重，采集速率
        foodCostRate.text = countNum((villagerAttribute == null) ? 0 : villagerAttribute.foodCost, (axeSoliderAttribute == null) ? 0 : axeSoliderAttribute.foodCost, (archerAttribute == null) ? 0 : archerAttribute.foodCost, (laborAttribute == null) ? 0 : laborAttribute.foodCost, (gatherersAttribute == null) ? 0 : gatherersAttribute.foodCost).ToString();
        waterCostRate.text = countNum((villagerAttribute == null) ? 0 : villagerAttribute.waterCost, (axeSoliderAttribute == null) ? 0 : axeSoliderAttribute.waterCost, (archerAttribute == null) ? 0 : archerAttribute.waterCost, (laborAttribute == null) ? 0 : laborAttribute.waterCost, (gatherersAttribute == null) ? 0 : gatherersAttribute.waterCost).ToString();
        weightNum.text = (countNum((villagerAttribute == null) ? 0 : villagerAttribute.addWeight, (axeSoliderAttribute == null) ? 0 : axeSoliderAttribute.addWeight, (archerAttribute == null) ? 0 : archerAttribute.addWeight, (laborAttribute == null) ? 0 : laborAttribute.addWeight, (gatherersAttribute == null) ? 0 : gatherersAttribute.addWeight) + defoultWeight).ToString();
        gatherRate.text = countNum((villagerAttribute == null) ? 0 : villagerAttribute.gatherRate, (axeSoliderAttribute == null) ? 0 : axeSoliderAttribute.gatherRate, (archerAttribute == null) ? 0 : archerAttribute.gatherRate, (laborAttribute == null) ? 0 : laborAttribute.gatherRate, (gatherersAttribute == null) ? 0 : gatherersAttribute.gatherRate).ToString();

        // 更改队伍最大负重
        maxWeight = int.Parse(weightNum.text);

        // 队伍携带资源
        foodInTroopSlider.maxValue = maxWeight / foodWeight/3;
        waterInTroopSlider.maxValue = maxWeight / waterWeight/3;
        foodInTroop.text = Mathf.RoundToInt(foodInTroopSlider.value).ToString();
        waterInTroop.text = Mathf.RoundToInt(waterInTroopSlider.value).ToString();

    }

    // 控制队伍最大人数和资源
    void TroopsInRange()
    {
        // 人数和不能超过最大人数
        if (Mathf.RoundToInt(villagerSlider.value) > maxPeopleNum - Mathf.RoundToInt(axeSoliderSlider.value) - Mathf.RoundToInt(archerSlider.value) - Mathf.RoundToInt(laborSlider.value) - Mathf.RoundToInt(gatherersSlider.value))
            villagerSlider.value = maxPeopleNum - Mathf.RoundToInt(axeSoliderSlider.value) - Mathf.RoundToInt(archerSlider.value) - Mathf.RoundToInt(laborSlider.value) - Mathf.RoundToInt(gatherersSlider.value);

        if (Mathf.RoundToInt(axeSoliderSlider.value) > maxPeopleNum - Mathf.RoundToInt(villagerSlider.value) - Mathf.RoundToInt(archerSlider.value) - Mathf.RoundToInt(laborSlider.value) - Mathf.RoundToInt(gatherersSlider.value))
            axeSoliderSlider.value = maxPeopleNum - Mathf.RoundToInt(villagerSlider.value) - Mathf.RoundToInt(archerSlider.value) - Mathf.RoundToInt(laborSlider.value) - Mathf.RoundToInt(gatherersSlider.value);

        if (Mathf.RoundToInt(archerSlider.value) > maxPeopleNum - Mathf.RoundToInt(axeSoliderSlider.value) - Mathf.RoundToInt(villagerSlider.value) - Mathf.RoundToInt(laborSlider.value) - Mathf.RoundToInt(gatherersSlider.value))
            archerSlider.value = maxPeopleNum - Mathf.RoundToInt(axeSoliderSlider.value) - Mathf.RoundToInt(villagerSlider.value) - Mathf.RoundToInt(laborSlider.value) - Mathf.RoundToInt(gatherersSlider.value);

        if (Mathf.RoundToInt(laborSlider.value) > maxPeopleNum - Mathf.RoundToInt(axeSoliderSlider.value) - Mathf.RoundToInt(archerSlider.value) - Mathf.RoundToInt(villagerSlider.value) - Mathf.RoundToInt(gatherersSlider.value))
            laborSlider.value = maxPeopleNum - Mathf.RoundToInt(axeSoliderSlider.value) - Mathf.RoundToInt(archerSlider.value) - Mathf.RoundToInt(villagerSlider.value) - Mathf.RoundToInt(gatherersSlider.value);

        if (Mathf.RoundToInt(gatherersSlider.value) > maxPeopleNum - Mathf.RoundToInt(axeSoliderSlider.value) - Mathf.RoundToInt(archerSlider.value) - Mathf.RoundToInt(laborSlider.value) - Mathf.RoundToInt(villagerSlider.value))
            gatherersSlider.value = maxPeopleNum - Mathf.RoundToInt(axeSoliderSlider.value) - Mathf.RoundToInt(archerSlider.value) - Mathf.RoundToInt(laborSlider.value) - Mathf.RoundToInt(villagerSlider.value);

        // 带走资源不能使仓库资源为负
        if (Mathf.RoundToInt(foodInTroopSlider.value) > foodInVillage)
            foodInTroopSlider.value = foodInVillage;
        if (Mathf.RoundToInt(waterInTroopSlider.value) > waterInVillage)
            waterInTroopSlider.value = waterInVillage;

    }

    public void OnSlider()
    {
        isChangeTroops = true;
    }
    #endregion

    // 队伍编辑完成，出发按钮
    public void DepartButton()
    {
        // 军队资源更新
        foodInArmy = Mathf.RoundToInt(foodInTroopSlider.value);
        waterInArmy= Mathf.RoundToInt(waterInTroopSlider.value);
        isArmyResourceChanged = true;
        // 村庄资源更新
        foodInVillage -= foodInArmy;
        waterInVillage -= waterInArmy;
        isVillageChanged = true;

        // 最终数量
        int villager = Mathf.RoundToInt(villagerSlider.value);
        int axeSolider= Mathf.RoundToInt(axeSoliderSlider.value);
        int archer = Mathf.RoundToInt(archerSlider.value);
        int labor = Mathf.RoundToInt(laborSlider.value);
        int gatherers = Mathf.RoundToInt(gatherersSlider.value);

        // 所有人
        GameObject[] allVillager = GameObject.FindGameObjectsWithTag("Villager");
        GameObject[] allAxeSolider = GameObject.FindGameObjectsWithTag("AxeSolider");
        GameObject[] allArcher = GameObject.FindGameObjectsWithTag("Archer");
        GameObject[] allLabor = GameObject.FindGameObjectsWithTag("Labor");
        GameObject[] allGatherers = GameObject.FindGameObjectsWithTag("Gatherers");

        // 创建队伍，将选定的队伍更改为isInArmy=true
        void CreateTroops(GameObject[] gameObjects,int num)
        {
            if(num != 0&&gameObjects !=null)
            {
                for (int i = 0; i < num; i++)
                    gameObjects[i].GetComponent<FollowLeader>().isInArmy = true;
            }
        }

        CreateTroops(allVillager, villager);
        CreateTroops(allAxeSolider, axeSolider);
        CreateTroops(allArcher, archer);
        CreateTroops(allLabor, labor);
        CreateTroops(allGatherers, gatherers);
    }

    // 点击新的征程按钮后解散原队伍
    public void Dissolve()
    {
        // 将军队资源放入仓库
        PutInStore();
        // 所有人
        GameObject[] allVillager = GameObject.FindGameObjectsWithTag("Villager");
        GameObject[] allAxeSolider = GameObject.FindGameObjectsWithTag("AxeSolider");
        GameObject[] allArcher = GameObject.FindGameObjectsWithTag("Archer");
        GameObject[] allLabor = GameObject.FindGameObjectsWithTag("Labor");
        GameObject[] allGatherers = GameObject.FindGameObjectsWithTag("Gatherers");

        void DissolveTroops(GameObject[] gameObjects)
        {
            if(gameObjects!=null)
            {
                for(int i=0;i<gameObjects.Length;i++)
                    gameObjects[i].GetComponent<FollowLeader>().isInArmy = false;
            }
        }

        DissolveTroops(allVillager);
        DissolveTroops(allAxeSolider);
        DissolveTroops(allArcher);
        DissolveTroops(allLabor);
        DissolveTroops(allGatherers);

    }

    // 初始化队伍资源
    public void StartTroopResouce()
    {
        foodInTroopSlider.maxValue = maxWeight / foodWeight;
        waterInTroopSlider.maxValue = maxWeight / waterWeight;
        foodInTroopSlider.value = 0;
        waterInTroopSlider.value = 0;
    }



}
