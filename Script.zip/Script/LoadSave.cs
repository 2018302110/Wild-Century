﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using UnityEngine.SceneManagement;

public class LoadSave : MonoBehaviour
{
    // 建筑prefab
    [SerializeField] GameObject smallHouse;
    [SerializeField] GameObject mediumHouse;
    [SerializeField] GameObject bigHouse;
    [SerializeField] GameObject smallStore;
    [SerializeField] GameObject bigStore;
    // 人物prefab
    [SerializeField] GameObject villager;
    [SerializeField] GameObject archer;
    [SerializeField] GameObject axeSolider;
    [SerializeField] GameObject labor;
    [SerializeField] GameObject gatherers;
    [SerializeField] GameObject leader;

    #region tag
    string villagerTag = "Villager";
    string archerTag = "Archer";
    string axeSoliderTag = "AxeSolider";
    string laborTag = "Labor";
    string gatherersTag = "Gatherers";
    string leaderTag = "Leader";
    string smallHouseTag = "SmallHouse";
    string mediumHouseTag = "MediumHouse";
    string bigHouseTag = "BigHouse";
    string smallStoreTag = "SmallStore";
    string bigStoreTag = "BigStore";
    #endregion


    private void Awake()
    {
        bool isGameScene = false;
        bool canLoad = PublicFunction.canLoad;

        string scenename = SceneManager.GetActiveScene().name;
        if (scenename == "GameScene")
        {
            isGameScene = true;
        }
        // 当前是游戏场景需读档
        if (canLoad && isGameScene)
        {
            LoadGame();
        }
    }
    // 读档
    public void LoadGame()
    {
        if (File.Exists(Application.persistentDataPath + "/gamesave.savefile"))
        {
            ClearStartObjects();
            // 创建一个 FileStream，让它读取字节流。然后生成一个 Save 对象并关闭 FileStream。
            BinaryFormatter bf = new BinaryFormatter();
            FileStream file = File.Open(Application.persistentDataPath + "/gamesave.savefile", FileMode.Open);
            SaveFile saveFile = (SaveFile)bf.Deserialize(file);
            file.Close();

            #region 加载物体
            void LoadObject(string objectTag, GameObject gameObject, int i)
            {
                if (saveFile.targetsTypes[i] == objectTag)
                {
                    Vector3 positionThis, vector3Rotation;
                    positionThis.x = saveFile.targetPositionsX[i];
                    positionThis.y = saveFile.targetPositionsY[i];
                    positionThis.z = saveFile.targetPositionsZ[i];
                    vector3Rotation.x = saveFile.targetRotationX[i];
                    vector3Rotation.y = saveFile.targetRotationY[i];
                    vector3Rotation.z = saveFile.targetRotationZ[i];
                    Quaternion rotationThis = Quaternion.Euler(vector3Rotation);
                    Instantiate(gameObject, positionThis, rotationThis);
                }
            }

            // 生成存档的物体
            for (int i = 0; i < saveFile.targetPositionsX.Count; i++)
            {
                LoadObject(villagerTag, villager, i);
                LoadObject(archerTag, archer, i);
                LoadObject(axeSoliderTag, axeSolider, i);
                LoadObject(laborTag, labor, i);
                LoadObject(gatherersTag, gatherers, i);
                LoadObject(smallHouseTag, smallHouse, i);
                LoadObject(mediumHouseTag, mediumHouse, i);
                LoadObject(bigHouseTag, bigHouse, i);
                LoadObject(smallStoreTag, smallStore, i);
                LoadObject(bigStoreTag, bigStore, i);

            }
            #endregion

            #region 加载资源
            ResourcesManager resource = GameObject.FindGameObjectWithTag("Ground").GetComponent<ResourcesManager>();

            resource.foodInArmy = saveFile.foodInArmy;
            resource.waterInArmy = saveFile.waterInArmy;
            resource.woodInArmy = saveFile.woodInArmy;
            resource.weaponInArmy = saveFile.weaponInArmy;
            resource.foodInVillage = saveFile.foodInVillage;
            resource.waterInVillage = saveFile.waterInVillage;
            resource.woodInVillage = saveFile.woodInVillage;
            resource.weaponInVillage = saveFile.weaponInVillage;
            resource.maxWeightStore = saveFile.maxWeightStore;
            #endregion

            Debug.Log("Game Loaded");
            //读档完将读档信号改为falses
            PublicFunction.canLoad  = false;

        }
        else
        {
            Debug.Log("No game saved!");
        }

    }

    // 清除初始的物体
    private void ClearStartObjects()
    {
        GameObject[] obj;
        obj = FindObjectsOfType(typeof(GameObject)) as GameObject[];//获取所有gameobject元素给数组obj
        foreach (GameObject targetGameObject in obj)
        {
            if (PublicFunction.IsBuilding(targetGameObject)||PublicFunction.IsVillager(targetGameObject))
            {
                DestroyImmediate(targetGameObject);
            }
        }
    }
}
