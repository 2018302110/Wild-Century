﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LeaderFollowRange : MonoBehaviour
{

    private void OnTriggerExit(Collider other)
    {
        if (PublicFunction.IsVillager(other.gameObject))
        {
            //脱离跟随
            other.gameObject.GetComponent<FollowLeader>().followed = false;

            //让村民换一个方向漫步，避免卡住
            if (other.gameObject.GetComponent<FollowLeader>().isInArmy)
                other.gameObject.GetComponent<VillagerGoAround>().GoAround();
        }
        if (other.gameObject.CompareTag("Altar"))
        {
            other.gameObject.GetComponent<AltarUI>().isLeaderAround = false;
        }
    }

    private void OnTriggerStay(Collider other)
    {
        if (PublicFunction.IsVillager(other.gameObject))
        {
            //已跟随
            other.gameObject.GetComponent<FollowLeader>().followed = true;
        }
        if (other.gameObject.CompareTag("Altar"))
        {
            //在祭坛附近
            other.gameObject.GetComponent<AltarUI>().isLeaderAround = true;
        }
    }
}
