﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CurrentPosition : MonoBehaviour
{
    public Text north;
    public Text east;

    void Update()
    {
        north.text = Mathf.RoundToInt(transform.position.z).ToString();
        east.text = Mathf.RoundToInt(transform.position.x).ToString();
    }
}
