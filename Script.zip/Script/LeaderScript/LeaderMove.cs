﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class LeaderMove : MonoBehaviour
{
    //Leader高度一半
    public float tall;
    [SerializeField] float leaderSpeed;
    //上次鼠标点击位置
    Vector3 hitPoint;
    CharacterController controller;

    void Start()
    {
        //初始化
        hitPoint = transform.position - new Vector3(0, tall, 0);
        controller = GetComponent<CharacterController>();
        tall = transform.position.y;
    }


    void Update()
    {
        //如果鼠标不在UI上
        if (!EventSystem.current.IsPointerOverGameObject())
        {
            hitPoint = PublicFunction.GetMouseHitPoint(hitPoint, "Ground");

            LeaderFollowMouse();
        }
    }

    void LeaderFollowMouse()
    {
        Vector3 offset = new Vector3(0, tall, 0);
        //移动的向量
        Vector3 walkTo = hitPoint - transform.position + offset;
        //player转身
        if (walkTo.magnitude > 0.5)
        {
            transform.forward = walkTo;
        }
        //未到达时
        if (walkTo.magnitude > 0.5)
        {
            controller.Move(walkTo.normalized * Time.deltaTime * leaderSpeed);
        }

    }
}
