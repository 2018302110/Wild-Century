﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LeaderOrderManager : MonoBehaviour
{
    public bool isWar = false;
    public bool isRetire = true;
    public bool isProduct = false;

}
