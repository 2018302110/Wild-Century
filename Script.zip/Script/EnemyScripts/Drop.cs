﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Drop : MonoBehaviour
{
    [SerializeField] GameObject foodLarge;
    [SerializeField] GameObject foodSmall;
    [SerializeField] GameObject weaponLarge;
    [SerializeField] GameObject weaponSmall;

    // 掉落的百分概率
    public float foodLargeProb;
    public float foodSmallProb;
    public float weaponLargeProb;
    public float weaponSmallProb;
    // 被打死才能掉落
    public bool canDrop = true;

    private void OnDestroy()
    {
        if (canDrop)
        {
            Vector3 offset = new Vector3(0, -0.5f, 0);
            float result = Random.Range(0f, 100f);
            // 试图掉一个物品
            if (result < weaponLargeProb)
            {
                Instantiate(weaponLarge, transform.position + offset, weaponLarge.transform.rotation);
                return;
            }
            if (result < foodLargeProb)
            {
                Instantiate(foodLarge, transform.position + offset, foodLarge.transform.rotation);
                return;
            }
            if (result < weaponSmallProb)
            {
                Instantiate(weaponSmall, transform.position + offset, weaponSmall.transform.rotation);
                return;
            }
            if (result < foodSmallProb)
            {
                Instantiate(foodSmall, transform.position + offset, foodSmall.transform.rotation);
                return;
            }
        }
    }
}
