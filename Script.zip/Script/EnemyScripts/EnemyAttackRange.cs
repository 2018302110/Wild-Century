﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAttackRange : MonoBehaviour
{
    public bool canAttack = false;

    private void OnTriggerStay(Collider other)
    {
        if (PublicFunction.IsVillager(other.gameObject))
            canAttack = true;
    }

    private void OnTriggerExit(Collider other)
    {
        if (PublicFunction.IsVillager(other.gameObject))
            canAttack = false;
    }
}
