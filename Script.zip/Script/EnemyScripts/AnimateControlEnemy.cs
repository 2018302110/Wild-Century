﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimateControlEnemy : MonoBehaviour
{
    public Animator animator;
    public bool isFightChanged = false;
    public bool isFight = false;


    void Update()
    {
        //改变时再重新赋值(可使没有采集或战斗动画的角色也用此类）
        if (isFightChanged)
        {
            animator.SetBool("isFight", isFight);
            isFightChanged = false;
        }
    }
}
