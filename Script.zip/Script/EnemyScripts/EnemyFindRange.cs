﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyFindRange : MonoBehaviour
{
    public bool isFind = false;
    public GameObject villager = null;

    private void OnTriggerStay(Collider other)
    {
        if (PublicFunction.IsVillager(other.gameObject))
        {
            isFind = true;
            villager = other.gameObject;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (PublicFunction.IsVillager(other.gameObject))
            isFind = false;
    }
}
