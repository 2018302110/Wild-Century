﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FindVillager : MonoBehaviour
{
    bool isFind, canAttack;
    public float attackRate;
    public float enemySpeed;
    public int _attack;
    bool coroutineHaveStarted = false;
    GameObject enemyFindRange, enemyAttackRange;
    GameObject villager;
    CharacterController controller;

    void Start()
    {
        controller = GetComponent<CharacterController>();
        //从属性管理类中获得攻击力
        _attack = GetComponent<AttributeManager>().attack;

        //从视野范围和攻击范围子物体中获得isFind和canAttack
        enemyFindRange = transform.Find("EnemyFindRange").gameObject;
        enemyAttackRange = transform.Find("EnemyAttackRange").gameObject;
        isFind = enemyFindRange.GetComponent<EnemyFindRange>().isFind;
        canAttack = enemyAttackRange.GetComponent<EnemyAttackRange>().canAttack;
        //从视野范围子物体中获得发现的村民
        villager = enemyFindRange.GetComponent<EnemyFindRange>().villager;
    }

    void Update()
    {
        //当发现村民时
        if (isFind)
        {
            //正在战斗，停止散步
            GetComponent<EnemyGoAround>().isFighting = true;
            //如果还不在攻击范围且村民未被队友消灭
            if (!canAttack && villager != null)
            {
                //向村民走去
                PublicFunction.Follow(villager, controller, enemySpeed, transform);
            }
            else
            {
                //如果控制战斗的协程未启动
                if (!coroutineHaveStarted)
                {
                    Fighting(villager);
                }

                //更改视野和攻击范围都无村民
                enemyFindRange.GetComponent<EnemyFindRange>().isFind = false;
                enemyAttackRange.GetComponent<EnemyAttackRange>().canAttack = false;
            }
        }
        //从视野和攻击范围触发器中获得新值
        isFind = enemyFindRange.GetComponent<EnemyFindRange>().isFind;
        canAttack = enemyAttackRange.GetComponent<EnemyAttackRange>().canAttack;
        //获取视野触发器的村民
        villager = enemyFindRange.GetComponent<EnemyFindRange>().villager;
        //找不到村民则未战斗，开始散步
        if (!isFind)
            GetComponent<EnemyGoAround>().isFighting = false;

    }

    void Fighting(GameObject villager)
    {
        StartCoroutine(Hurt(villager));
    }

    IEnumerator Hurt(GameObject villager)
    {
        coroutineHaveStarted = true;
        //如果村民未被消灭
        if (villager != null)
        {
            //如果村民血量大于0
            while (villager != null && villager.GetComponent<AttributeManager>().HP > 0)
            {
                //如果自己没被打死
                if (this != null)
                {
                    //播放战斗动画
                    GetComponent<AnimateControlEnemy>().animator.SetBool("isFight", true);
                    GetComponent<AnimateControlEnemy>().isFightChanged = true;
                    //村民减血
                    villager.GetComponent<AttributeManager>().HP -= _attack;
                }
                //等待一个前摇
                yield return new WaitForSeconds(attackRate);
            }
            //销毁村民
            Destroy(villager);
            Debug.Log("怪物胜利");
            //取消播放战斗动画
            GetComponent<AnimateControlEnemy>().animator.SetBool("isFight", false);
            GetComponent<AnimateControlEnemy>().isFightChanged = true;
        }

        //更改视野和攻击范围都无村民
        enemyFindRange.GetComponent<EnemyFindRange>().isFind = false;
        enemyAttackRange.GetComponent<EnemyAttackRange>().canAttack = false;
        //协程未启动
        coroutineHaveStarted = false;

        yield return null;
    }
}
