﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyGoAround : MonoBehaviour
{
    public float enemyWalkSpeed = 4f;
    public bool isFighting = false;
    CharacterController controller;
    public Vector3 RandomVector;

    void Start()
    {
        float changeDirectionRate = Random.Range(5, 15);
        controller = gameObject.GetComponent<CharacterController>();
        InvokeRepeating("GoAround", 0.5f, changeDirectionRate);
    }

    void Update()
    {
        //如果没有被挤到半空中的话（Move函数会妨碍OnGround的执行）
        if (transform.position.y < 0.6f)
        {
            //没有战斗就散步
            if (!isFighting)
            {
                controller.Move(RandomVector.normalized * enemyWalkSpeed * Time.deltaTime);
                if (RandomVector.magnitude > 0.1)
                    transform.forward = Vector3.Lerp(transform.forward,RandomVector,0.05f);
            }
        }
    }

    void GoAround()
    {
        //获得一个随机方向
        float x = Random.Range(-3, 3);
        float z = Random.Range(-3, 3);
        RandomVector = new Vector3(x, 0, z);
    }
}
