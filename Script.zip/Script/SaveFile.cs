﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class SaveFile 
{

    // 要存的物体的位置和旋转
    public List<float> targetPositionsX = new List<float>();
    public List<float> targetPositionsY = new List<float>();
    public List<float> targetPositionsZ = new List<float>();
    public List<float> targetRotationX = new List<float>();
    public List<float> targetRotationY = new List<float>();
    public List<float> targetRotationZ = new List<float>();

    // 存物体tag
    public List<string> targetsTypes = new List<string>();

    // 存资源数量
    public int foodInArmy = 0;
    public int waterInArmy = 0;
    public int woodInArmy = 0;
    public int weaponInArmy = 0;
    public int foodInVillage = 0;
    public int waterInVillage = 0;
    public int woodInVillage = 0;
    public int weaponInVillage = 0;
    public int maxWeightStore = 0;
}
